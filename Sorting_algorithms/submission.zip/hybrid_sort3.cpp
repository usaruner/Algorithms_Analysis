#include "project1.h"
#include <math.h>
std::vector<int> mergeH3(std::vector<int>& A, std::vector<int>& B) {
    std::vector<int> S = std::vector<int>();
    int i = 0;
    int j = 0;
    while (i < (int)A.size() && j < (int)B.size()) {
        if (A[i] <= B[j]) {
            S.push_back(A[i]);
            i++;
        }
        else {
            S.push_back(B[j]);
            j++;
        }
    }
    while (i < (int)A.size()) {
        S.push_back(A[i]);
        i++;
    }
    while (j < (int)B.size()) {
        S.push_back(B[j]);
        j++;
    }
    return S;
}
void hybrid_sort_helper3(std::vector<int>& nums, int H) {
    if ((int)nums.size() > H) {

        std::vector<int>  A = std::vector<int>(nums.begin(), nums.end() - nums.size() / 2);
        std::vector<int> B = std::vector<int>(nums.end() - nums.size() / 2, nums.end());
        hybrid_sort_helper3(A, H);
        hybrid_sort_helper3(B, H);
        nums = mergeH3(A, B);
    }
    else {
        insertion_sort(nums);
    }
}

void hybrid_sort3(std::vector<int>& nums)
{
    int H = pow((int)nums.size(),(double)(1/6));
    if (H < 1) {
        H = 1;
    }
    if ((int)nums.size() > H) {
        std::vector<int>  A = std::vector<int>(nums.begin(), nums.end() - nums.size() / 2);
        std::vector<int> B = std::vector<int>(nums.end() - nums.size() / 2, nums.end());
        hybrid_sort_helper3(A, H);
        hybrid_sort_helper3(B, H);
        nums = mergeH3(A, B);
    }
    else {
        insertion_sort(nums);
    }
}
