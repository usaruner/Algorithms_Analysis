#include "project1.h"
void insertion_sort(std::vector<int>& nums) {
    int swapPos = 0;
    for (int i = 0; i < (int)(nums.size()); i++) {
        swapPos = 0;
        for (int j = i - 1; j >= 0; j--) {
            if (nums[j] <= nums[i]) {
                swapPos = j + 1;
                break;
            }
        }
        //insertsion/delete
        nums.insert(nums.begin() + swapPos, *(nums.begin() + i));
        nums.erase(nums.begin() + i + 1);
    }

}
