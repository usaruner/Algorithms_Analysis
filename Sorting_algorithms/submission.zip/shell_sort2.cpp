#include "project1.h"


void shell_sort2(std::vector<int>& nums) {
    int gap_size = 0;
    int shell_num[] = { 1, 3, 5, 9, 17, 33, 65, 129, 257, 513, 1025, 2049, 4097, 8193};
    int pos_max = 0;
    for (int i = 0; i < (int)(sizeof(shell_num) / sizeof(shell_num[0])); i++) {
        if (shell_num[i] > (int)nums.size()) {
            pos_max = i - 1;
            break;
        }
    }
    for (int gap = pos_max; gap >= 0; gap--)
    {
        gap_size = shell_num[gap];
        for (int i = 0; i < gap_size; i++) {
                sort_with_gaps(nums, gap_size, i);
        }
    }
}