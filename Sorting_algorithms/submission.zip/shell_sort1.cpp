#include "project1.h"
void swap(int& A, int& B) {
    int temp = A;
    A = B;
    B = temp;
}
void sort_with_gaps(std::vector<int>& nums, int gaps, int start) {
    int swapPos = 0;

    for (int i = start; i < (int)nums.size(); i += gaps) {
        swapPos = 0;
        for (int j = i; j >= 0; j -= gaps) {
            if (j < (int)nums.size() && i != j) {
                if (nums[i - swapPos] < nums[j]) {
                    swap(nums[j], nums[i - swapPos]);
                    swapPos += gaps;
                }
            }
        }
    }
}
void shell_sort1(std::vector<int>& nums)
{

    for (int gap = (int)nums.size() / 2; gap > 0; gap /= 2)
    {
        for (int i = 0; i < gap; i++) {
            sort_with_gaps(nums, gap, i);
        }
    }
}