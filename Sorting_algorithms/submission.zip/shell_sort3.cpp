#include "project1.h"


void shell_sort3(std::vector<int>& nums) {
    int shell_num[] = { 1, 2, 3, 4, 6, 8, 9, 12, 16, 18, 24, 27, 32, 36, 48, 54, 64, 72, 81, 96, 108, 128, 144, 162, 192, 216, 243, 256 };
    int pos_max = 0;
    for (int i = 0; i < (int)(sizeof(shell_num) / sizeof(shell_num[0])); i++) {
        if (shell_num[i] > (int)nums.size()) {
            pos_max = i - 1;
            break;
        }
    }
    int gap_size = 0;
    for (int gap = pos_max; gap >= 0; gap--)
    {
        gap_size = shell_num[gap];
        for (int i = 0; i < gap_size; i++) {
            if (i < (int)nums.size()) {
                sort_with_gaps(nums, gap_size, i);
            }
        }
    }
}