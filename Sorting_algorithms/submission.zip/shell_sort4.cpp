#include "project1.h"
#include <iostream>
void printVec(std::vector<int>& nums) {
    for (std::vector<int>::iterator it = nums.begin(); it < nums.end(); it++) {
        std::cout << *(it) << ", ";
    }
    std::cout << std::endl;
}

void shell_sort4(std::vector<int>& nums) {
    
    int shell_num[] = { 1, 5, 19, 41, 109, 209, 505, 929, 2161, 3905 };
    int pos_max = 0;
    for (int i = 0; i < (int)(sizeof(shell_num) / sizeof(shell_num[0])); i++) {
        if (shell_num[i] > (int)nums.size()) {
            pos_max = i;
            break;
        }
    }
    int gap_size = 0;
    for (int gap = pos_max; gap >= 0; gap--)
    {
        gap_size = shell_num[gap];

        for (int i = 0; i < gap_size; i++) {
                printVec(nums);
                std::cout << gap << ", "  << gap_size << ", " << (int)i << std::endl;
                sort_with_gaps(nums, gap_size, i);
        }
    }
}