#include "project1.h"
#include <iostream>
std::vector<int> merge(std::vector<int>& A, std::vector<int>& B) {
    std::vector<int> S = std::vector<int>();
    int i = 0;
    int j = 0;
    while (i < (int)A.size() && j < (int)B.size()) {
        if (A[i] <= B[j]) {
            S.push_back(A[i]);
            i++;
        }
        else {
            S.push_back(B[j]);
            j++;
        }
    }
    while (i < (int)A.size()) {
        S.push_back(A[i]);
        i++;
    }
    while (j < (int)B.size()) {
        S.push_back(B[j]);
        j++;
    }
    return S;
}
void merge_sort(std::vector<int>& nums) {
    std::vector<int>  A = std::vector<int>(nums.begin(), nums.end() - nums.size() / 2);
    std::vector<int> B = std::vector<int>(nums.end() - nums.size() / 2, nums.end());
    if (nums.size() > 1) {
        merge_sort(A);
        merge_sort(B);
    }
    nums = merge(A, B);
}